/**************************************************/
Assignment No- 5
Course       - Human and Machine Speech Communication  CRL707

Submission By : Parveen Bajaj, EET20182574

Details of files submitted are:-

a. Parveen_5.m contains the matlab code.

b. Parveen_0_9.wav contains speech signals recorded during assignment-1 for the experimentation.

c. Report in pdf format contains
         - Solution to Problem Q6 
         - All the results 
         - Code

          